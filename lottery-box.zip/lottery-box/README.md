# Lottery box

A Pen created on CodePen.io. Original URL: [https://codepen.io/ShradhaVastrakar/pen/dygrWaK](https://codepen.io/ShradhaVastrakar/pen/dygrWaK).

